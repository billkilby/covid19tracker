#Relevant Imports
import requests
import sched
import time
import json

#Function for requesting news content
def news_API_request(covid_terms="Covid COVID-19 coronavirus",apiKey="8142cacff7114a98bbfc110e22be41d1"):
    #Converts covid terms into format accepted by API
    covid_terms = "q="+(covid_terms.replace(" ", "&"))+"&"
    #Generates the URL string
    url= ("https://newsapi.org/v2/everything?"
         +covid_terms+
         "sortBy=relevancy&"
         "apiKey="+apiKey
        )
    #Asks for the response in json string format
    responseJson = (requests.get(url)).text
    #Converts Json string to python dict
    response = json.loads(responseJson)
    newsData=[]
    #Derives required information from the dictionary (only title and content)
    for x in range (0, len(response["articles"])):
        tempDict={}
        tempDict["title"]=response["articles"][x]["title"]
        tempDict["content"]=response["articles"][x]["description"]
        newsData.append(tempDict)
    #Returns required data
    return(newsData)

#Function for updating news 
def update_news(search_terms):
    #Sets up scheduler
    s = sched.scheduler(time.time, time.sleep)
    if s.empty():
        #If the scheduler is empty, it sets up an update in 10 seconds.
        e1 = s.enter(10,1,news_API_request,argument=(search_terms,))
        s.run()

#Test Functions (Must be run in Console)
def test_news_API_request():
    assert news_API_request()
    assert news_API_request('Covid COVID-19 coronavirus') == news_API_request()

def test_update_news():
    test = update_news('test')
