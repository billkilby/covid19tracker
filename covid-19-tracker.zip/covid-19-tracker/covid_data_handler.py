#Relevant Imports
import csv, sched, time
from uk_covid19 import Cov19API
import json

#Function to parse CSV data from example file
def parse_csv_data(csv_filename):
    with open(csv_filename, newline="") as csv_file:
        #Reads the CSV data and saves it to a var
        tempData = csv.reader(csv_file)
        fileData = []
        #Loops through the data to makes it into a string
        for line in tempData:
            fileData.append(line)
        return(fileData)


def process_covid_csv_data(covid_csv_data):
    #For loops provide a level of security - if there is a day where the data is bugged/broken, it will ignore that day rather than break.
    
    #Number of cases in the past 7 days
    totalCases = 0
    #Loops through every item in the list
    for a in range (1, len(covid_csv_data)):
        #Checks to see if there is a data entry (so that incomplete data does not break the system)
        if covid_csv_data[a][6] is not None and covid_csv_data[a][6] != "":
            #When found, adds the next 6 days and breaks out of loop
            for x in range (a+1,a+8): 
                totalCases = totalCases + int(covid_csv_data[x][6])
            break

    #Cumulative Deaths
    #Loops through every item in the list
    for b in range (1,len(covid_csv_data)):
        #Checks to see if the item has a data entry
        if covid_csv_data[b][4] is not None and covid_csv_data[b][4] != "":
            #Sets variable to first item with data
            cumulativeDeaths = int(covid_csv_data[b][4])
            break

    #Current Hospital Cases
    #Does the same as the above but looks for hospital cases instead
    for c in range (1, len(covid_csv_data)):
        if covid_csv_data[c][5] is not None and covid_csv_data[c][5] != "":
            currentHospitalCases = int(covid_csv_data[c][5])
            break
       
    return(totalCases,currentHospitalCases,cumulativeDeaths)


#Functions relating to real live data from the uk_covid19 module:
def covid_API_request(update_name="No Update Name Set"):
    #Loads the config file
    with open("config.json") as configFile:
        configInfo = json.load(configFile)
        #This section returns the neccessary information for the local data, and can be changed through the config file.
        localInfo = {
            "date" : "date",
            "areaName": "areaName",
            "areaCode": "areaCode",
            "newCasesByPublishDate": "newCasesByPublishDate"
            }

        #Filters affected by Config file
        currentFilters = [
            "areaType="+str(configInfo["Local_Location_Type"]),
            "areaName="+str(configInfo["Local_Location"])
            ]

        #Requests information from the API
        api = Cov19API(filters=currentFilters, structure=localInfo)

        #Converts the information to a json string
        localJson = (api.get_json(as_string="True"))

        #Converts the information to a python dictionary
        localData = json.loads(localJson)
               
        #This section returns the neccesary information for the national data, and takes information from the config file.
        #This section works identical to the above
        nationalInfo={
            "date" : "date",
            "areaType" : "areaType",
            "areaName" : "areaName",
            "newCasesByPublishDate": "newCasesByPublishDate",
            "cumCasesByPublishDate" : "cumCasesByPublishDate",
            "hospitalCases" : "hospitalCases",
            "cumDeaths28DaysByDeathDate" : "cumDeaths28DaysByDeathDate"
            }

        #Filters affected by Config Dfile
        currentFilters = [
            "areaType="+str(configInfo["Nation_Type"]),
            "areaName="+str(configInfo["Nation_Location"])
            ]

        api = Cov19API(filters=currentFilters,structure=nationalInfo)

        nationalJson = (api.get_json(as_string="True"))

        nationalData = json.loads(nationalJson)

        #The data is then sent off to process_API_data() and returns the relevant information
        local7Day,national7Day,hospitalCases,totalDeaths = process_API_data(localData,nationalData)

        return(local7Day,national7Day,hospitalCases,totalDeaths,update_name)

def process_API_data(localData,nationalData):
    #Calculates the local 7 day amount by finding the first point of data and then adding the next 6
    local7Day=0
    for y in range (0,7):
        local7Day = local7Day + localData["data"][y]["newCasesByPublishDate"]
    #Calculates the national 7 day amount through the same method as above
    national7Day=0
    for y in range (0,7):
        national7Day = national7Day + nationalData["data"][y]["newCasesByPublishDate"]

    #Finds most recent hospital cases and then sets hospital cases
    if nationalData["data"][0]["hospitalCases"] is not None:
        hospitalCases = nationalData["data"][0]["hospitalCases"]
    else:
        hospitalCases = nationalData["data"][1]["hospitalCases"]

    #Same as above but for cumulative deaths up to current
    if nationalData["data"][0]["cumDeaths28DaysByDeathDate"] is not None:
        totalDeaths = nationalData["data"][0]["cumDeaths28DaysByDeathDate"]
    else:
        totalDeaths = nationalData["data"][1]["cumDeaths28DaysByDeathDate"]

    return(local7Day,national7Day,hospitalCases,totalDeaths)
    

#Update Function
def schedule_covid_updates(update_interval, update_name):
    #Sets up scheduler
    s = sched.scheduler(time.time, time.sleep)
    if s.empty():
        #Checks if it is empty - if not, it will queue another update to happen at update_interval
        e1 = s.enter(update_interval,1,covid_API_request,argument=(update_name,))
        s.run()


#Test Functions (Must be run from Console)
def test_parse_csv_data():
    data = parse_csv_data('nation_2021-10-28.csv')
    assert len(data) == 639

def test_process_covid_csv_data():
    last7days_cases , current_hospital_cases , total_deaths = \
        process_covid_csv_data ( parse_csv_data (
            'nation_2021-10-28.csv' ) )
    assert last7days_cases == 240299
    assert current_hospital_cases == 7019
    assert total_deaths == 141544

def test_covid_API_request():
    localData, nationalData = covid_API_request()
    assert isinstance(localData, dict)
    assert isinstance(nationalData, dict)

def test_schedule_covid_updates():
    schedule_covid_updates(update_interval=10, update_name='update test')





