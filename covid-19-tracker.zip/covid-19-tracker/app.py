#Json import
import json

#Relevant flask imports
from flask import Flask
from flask import render_template
from flask import request

#Relevant covid_news_handling imports
from covid_news_handling import news_API_request
from covid_news_handling import update_news

#Relevant covid_data_handler imports

from covid_data_handler import covid_API_request

#Relevant time / scheduling imports
import sched
import time
import datetime

#Importing logging module
import logging

s = sched.scheduler(time.time, time.sleep)

#Loading the config file
logging.basicConfig(filename="app.log",encoding="utf-8")

#Making the main variables global so that they can be accessed from anywhere.
newsArticles=[]
removedTitle = ""
removedUpdate = ""
local7Day = 0
national7Day = 0
hospitalCases = 0
totalDeaths = 0
update_name = ""
updates=[]

#Opens the config file so that the values can be passed on
with open("config.json") as configFile:
    #Json module loads the config file as a python dict
    configInfo = json.load(configFile)
    #Calls functions to set up first data when ran
    newsArticles = news_API_request(configInfo["Search_Terms"],configInfo["API_Key"])
    local7Day,national7Day,hospitalCases,totalDeaths,update_name=covid_API_request()   


    #Update functions to be used within the app
    def updateCovid():
        #Declares the variables as the global ones so that they can be updated within the scope of the function
        global local7Day,national7Day,hospitalCases,totalDeaths,update_name
        #Updates the variables
        local7Day,national7Day,hospitalCases,totalDeaths,update_name=covid_API_request()
        #Removes the update
        updates.pop(0)
        #Recalls main so it "re-renders"
        main()
        
    def updateNews():
        #Declares the list as a global so it can be changed within the scope of the function
        global newsArticles
        #Updates the articles
        newsArticles = news_API_request(configInfo["Search_Terms"],configInfo["API_Key"])
        #Removes the update
        updates.pop(0)
        #Recalls main so it "re-renders"
        main()
        
    def removeNews(removedTitle):
        #Lists through newsArticles[], once the title matches the removed title, it pops it out of the list and breaks.
        for item in range(0, len(newsArticles)):
            if newsArticles[item]["title"] == removedTitle:
                newsArticles.pop(item)
                break

    def removeUpdate(removedUpdate):
        #Lists through updates[], once the title matches the removed title, it pops it out of the list and breaks.
        for item in range(0, len(updates)):
            if updates[item]["title"]==removedUpdate:
                updates.pop(item)
                break


    #Starts the app
    app = Flask(__name__)

    @app.route("/index")
    

    def main():
        s.run(blocking=False)
        #Gets all the relevant information for the news/covid update.
        updateTime = request.args.get("update")
        updateName = request.args.get("two")
        repeat = request.args.get("repeat")
        covidUpdate = request.args.get("covid-data")
        newsUpdate = request.args.get("news")
        #For the news removals
        removedTitle = request.args.get("notif")
        #For update clearing
        removedUpdate = request.args.get("update_item")
        #Checks if the main update has been selected (Update Time)
        if updateTime is not None:
            #Calculates time between defined and current.
            realTime = (datetime.datetime.strptime(updateTime,"%H:%M")) - (datetime.datetime.strptime(time.strftime("%H:%M:%S"),"%H:%M:%S"))
            
            #Multiple checks to see what options have been added, and then passes it onto main
            if repeat is not None and covidUpdate is not None and newsUpdate is not None:
                s.enter(int(realTime.total_seconds()), 1, updateCovid)
                s.enter(int(realTime.total_seconds()), 1, updateNews)
                updates.append({"title": updateName, "content": "Covid and News Update @ "+str(updateTime)})

                #Because of repeat, adding 24 hours onto it.
                s.enter(int(realTime.total_seconds())+86400, 1, updateCovid)
                s.enter(int(realTime.total_seconds())+86400, 1, updateNews)
                updates.append({"title": updateName+" (Repeat)", "content": "Covid and News Update @ "+str(updateTime)+" tomorrow"})
                
            elif repeat is not None and covidUpdate is not None:
                s.enter(int(realTime.total_seconds()), 1, updateCovid)
                updates.append({"title": updateName, "content": "Covid Update @ "+str(updateTime)})
                #24 Hour Update because of repeat
                s.enter(int(realTime.total_seconds())+86400, 1, updateCovid)
                updates.append({"title": updateName+" (Repeat)", "content": "Covid Update @ "+str(updateTime)+" tomorrow"})

            elif repeat is not None and newsUpdate is not None:
                s.enter(int(realTime.total_seconds()), 1, updateNews)
                updates.append({"title": updateName, "content": "News Update @ "+str(updateTime)+" tomorrow"})

                #24 Hour Update because of repeat
                s.enter(int(realTime.total_seconds())+86400, 1, updateNews)
                updates.append({"title": updateName+" (Repeat)", "content": "News Update @ "+str(updateTime)+" tomorrow"})

            elif covidUpdate is not None:
                s.enter(int(realTime.total_seconds()), 1, updateCovid)
                updates.append({"title": updateName, "content": "Covid Update @ "+str(updateTime)})

            elif newsUpdate is not None:
                s.enter(int(realTime.total_seconds()), 1, updateNews)
                updates.append({"title": updateName, "content": "News Update @ "+str(updateTime)})

        #Second checker which checks if a news article has been removed.
        if removedTitle is not None:
            removeNews(removedTitle)
        #Third checker which checks if an update has been removed or not
        if removedUpdate is not None:
            removeUpdate(removedUpdate)
        #Renders the template with all necessary information
        return render_template("template.html",
            title = "Covid-19 Tracker",
            location = configInfo["Local_Location"],
            local_7day_infections = local7Day,
            nation_location = configInfo["Nation_Location"],
            national_7day_infections = national7Day,
            hospital_cases = "Hospital Cases: "+str(hospitalCases),
            deaths_total = "Total Deaths: "+str(totalDeaths),
            news_articles = newsArticles,
            updates=updates)
    #Checks if the python module is running it
    if __name__ == "__main__":
        app.run()


